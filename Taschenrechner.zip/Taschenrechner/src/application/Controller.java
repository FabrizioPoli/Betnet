package application;
import javafx.scene.text.Text;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import java.awt.event.ActionEvent;

public class Controller {

    @FXML
    Text resultLabel;

    boolean isTypingNumber = false;
    double firstNumber = 0;
    double secondNumber = 0;
    String operation = "";

    Model model = new Model();

    public void numberTapped(javafx.event.ActionEvent actionEvent) {

        String value = ((Button)actionEvent.getSource()).getText();

        if (isTypingNumber) {
            resultLabel.setText(resultLabel.getText() + value);
        } else {
            resultLabel.setText(value);
            isTypingNumber = true;
        }
    }

    public void calculationTapped(javafx.event.ActionEvent actionEvent) {
        isTypingNumber = false;
        firstNumber = Double.parseDouble(resultLabel.getText());
        operation = ((Button)actionEvent.getSource()).getText();

    }

    public void equalTapped(javafx.event.ActionEvent actionEvent) {
        isTypingNumber = false;
        secondNumber = Double.parseDouble(resultLabel.getText());

        double result = model.calculate(firstNumber, secondNumber, operation);

        resultLabel.setText(String.valueOf(result));
    }

    public void restartTapped(javafx.event.ActionEvent actionEvent) {
        resultLabel.setText("0");
        firstNumber = 0;
        secondNumber = 0;

    }


}
